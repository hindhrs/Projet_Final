import pandas as pd
import numpy as np
from bokeh.layouts import column
from bokeh.models import ColumnDataSource, HoverTool, Select, CustomJS, LinearColorMapper, ColorBar
from bokeh.plotting import figure, curdoc
from bokeh.transform import linear_cmap
from bokeh.palettes import  RdYlBu11 as palette
from bokeh.palettes import Viridis256
from sklearn.linear_model import LinearRegression
from bokeh.layouts import column
from bokeh.models import ColumnDataSource, HoverTool, Select
from bokeh.plotting import figure, curdoc
from data_manager import AgriculturalDataManager


class AgriculturalDashboard:
    def __init__(self, data_manager):
        self.data_manager = data_manager
        self.source = None
        self.hist_source = None
        self.create_data_sources()

    def create_data_sources(self):
        self.hist_source = ColumnDataSource(self.data_manager.yield_history)
        self.source = ColumnDataSource(self.data_manager.monitoring_data)

    def create_yield_history_plot(self):
        p = figure(
            title="Historique des Rendements par Parcelle",
            x_axis_type="datetime",
            height=400,
            tools="pan,wheel_zoom,box_zoom,reset",
        )
        grouped_data = self.data_manager.yield_history.groupby('annee')['rendement_final'].mean().reset_index()
        source = ColumnDataSource(grouped_data)
        p.line(x='annee', y='rendement_final', source=source, line_width=2, color="blue", legend_label="Rendement moyen")
        p.scatter(x='annee', y='rendement_final', source=source, size=8, color="red", legend_label="Points")

        hover = HoverTool(tooltips=[("Année", "@annee{%F}"), ("Rendement moyen", "@rendement_final")],
                          formatters={"@annee": "datetime"})
        p.add_tools(hover)
        p.xaxis.axis_label = "Année"
        p.yaxis.axis_label = "Rendement moyen (t/ha)"

        return p

    def create_ndvi_temporal_plot(self):
        """
        Crée un graphique montrant l’évolution du NDVI avec des seuils historiques.
        """
        if 'ndvi' not in self.data_manager.monitoring_data.columns:
            print("Warning: NDVI column is missing!")
            return figure(title="NDVI (Données Manquantes)", height=400)

        # Aggregate NDVI data by week
        monitoring_data = self.data_manager.monitoring_data.copy()
        monitoring_data['week'] = monitoring_data['date'].dt.to_period('W').apply(lambda r: r.start_time)
        aggregated_data = monitoring_data.groupby('week')['ndvi'].mean().reset_index()

        # Create ColumnDataSource
        source = ColumnDataSource(aggregated_data)

        # Create the plot
        p = figure(
            title="Évolution du NDVI et Seuils Historiques",
            x_axis_type="datetime",
            height=400,
            tools="pan,wheel_zoom,box_zoom,reset",
        )

        # Add NDVI line
        p.line(x='week', y='ndvi', source=source, line_width=2, color="green", legend_label="NDVI")
        p.scatter(x='week', y='ndvi', source=source, size=5, color="green", legend_label="NDVI")

        # Add tooltips
        hover = HoverTool(
            tooltips=[("Semaine", "@week{%F}"), ("NDVI", "@ndvi{0.2f}")],
            formatters={"@week": "datetime"},
        )
        p.add_tools(hover)

        # Axis labels
        p.xaxis.axis_label = "Date"
        p.yaxis.axis_label = "NDVI"

        return p

    def create_stress_matrix(self):
        """
        Crée une matrice de stress combinant stress hydrique et conditions météorologiques.
        """
        # Ensure the required columns exist
        if 'stress_hydrique' not in self.data_manager.monitoring_data.columns:
            print("Warning: Hydric stress data is missing!")
            return figure(title="Matrice de Stress (Données Manquantes)", height=400)

        # Derive 'weather_stress' from weather data
        weather_data = self.data_manager.weather_data.copy()
        weather_data['weather_stress'] = (weather_data['temperature'] / weather_data['temperature'].max()) + \
                                        (1 - weather_data['humidite'] / weather_data['humidite'].max()) + \
                                        (weather_data['precipitation'] / weather_data['precipitation'].max())

        # Normalize the 'weather_stress' column
        weather_data['weather_stress'] = weather_data['weather_stress'] / weather_data['weather_stress'].max()

        # Join weather stress with monitoring data
        merged_data = self.data_manager.monitoring_data.copy()
        merged_data = merged_data.merge(weather_data[['date', 'weather_stress']], on='date', how='left')

        # Drop rows with missing stress data
        stress_data = merged_data.dropna(subset=['stress_hydrique', 'weather_stress'])

        # Create ColumnDataSource
        source = ColumnDataSource(stress_data)

        # Create the plot
        p = figure(
            title="Matrice de Stress",
            x_range=(0, 1),  # Assuming stress levels are normalized between 0 and 1
            y_range=(0, 1),
            height=400,
            tools="pan,wheel_zoom,box_zoom,reset",
        )

        # Add scatter points
        mapper = linear_cmap(field_name='stress_hydrique', palette=Viridis256, low=0, high=1)
        p.scatter(
            x='stress_hydrique',
            y='weather_stress',
            size=10,
            source=source,
            color=mapper,
            alpha=0.7,
            legend_label="Stress Levels",
        )

        # Add tooltips
        hover = HoverTool(
            tooltips=[
                ("Hydric Stress", "@stress_hydrique"),
                ("Weather Stress", "@weather_stress"),
                ("Parcel ID", "@parcelle_id"),
            ]
        )
        p.add_tools(hover)

        # Add axis labels
        p.xaxis.axis_label = "Stress Hydrique"
        p.yaxis.axis_label = "Stress Climatique"

        # Customize legend
        p.legend.location = "top_left"

        return p

    def create_yield_prediction_plot(self):
        """
        Crée un graphique de prédiction des rendements basé sur les données historiques et actuelles.
        """
        # Aggregate historical data by year
        historical_data = self.data_manager.yield_history.groupby('annee')['rendement_final'].mean().reset_index()

        # Prepare data for linear regression (simple prediction model)
        X = historical_data[['annee']].values
        y = historical_data['rendement_final'].values

        # Train linear regression model
        model = LinearRegression()
        model.fit(X, y)

        # Predict future yields (e.g., for the next 5 years)
        future_years = np.arange(X[-1][0] + 1, X[-1][0] + 6).reshape(-1, 1)  # Next 5 years
        predicted_yields = model.predict(future_years)

        # Combine historical and predicted data for visualization
        future_data = pd.DataFrame({
            'annee': future_years.flatten(),
            'rendement_final': predicted_yields
        })
        combined_data = pd.concat([historical_data, future_data])

        # Create Bokeh ColumnDataSource
        source = ColumnDataSource(combined_data)

        # Create the plot
        p = figure(
            title="Prédiction des Rendements",
            x_axis_type="linear",
            height=400,
            tools="pan,wheel_zoom,box_zoom,reset",
        )

        # Add historical data
        p.line(x='annee', y='rendement_final', source=source, line_width=2, color="blue", legend_label="Historique")
        p.scatter(x='annee', y='rendement_final', source=source, size=8, color="blue", legend_label="Historique")

        # Add predicted data
        future_source = ColumnDataSource(future_data)
        p.line(x='annee', y='rendement_final', source=future_source, line_width=2, color="green", legend_label="Prédiction")
        p.scatter(x='annee', y='rendement_final', source=future_source, size=8, color="green", legend_label="Prédiction")

        # Add tooltips
        hover = HoverTool(tooltips=[("Année", "@annee"), ("Rendement", "@rendement_final")])
        p.add_tools(hover)

        # Add axis labels
        p.xaxis.axis_label = "Année"
        p.yaxis.axis_label = "Rendement (t/ha)"

        # Customize legend
        p.legend.location = "top_left"
        return p

    def get_parcelle_options(self):
        """
        Retourne la liste des parcelles disponibles.
        """
        if 'parcelle_id' not in self.data_manager.monitoring_data.columns:
            print("Warning: Parcel IDs are missing!")
            return []
        return sorted(self.data_manager.monitoring_data['parcelle_id'].unique())

    def prepare_stress_data(self):
        """
        Prépare les données pour la matrice de stress.
        """
        if 'stress_hydrique' not in self.data_manager.monitoring_data.columns:
            print("Warning: Hydric stress data is missing!")
            return pd.DataFrame()

        # Ensure 'weather_stress' is computed in weather data
        if 'weather_stress' not in self.data_manager.weather_data.columns:
            print("Computing weather_stress from weather data...")
            weather_data = self.data_manager.weather_data.copy()
            weather_data['weather_stress'] = (weather_data['temperature'] / weather_data['temperature'].max()) + \
                                            (1 - weather_data['humidite'] / weather_data['humidite'].max()) + \
                                            (weather_data['precipitation'] / weather_data['precipitation'].max())
            weather_data['weather_stress'] = weather_data['weather_stress'] / weather_data['weather_stress'].max()
            self.data_manager.weather_data = weather_data  # Update the data manager with the computed column

        # Merge and normalize stress data
        stress_data = self.data_manager.monitoring_data[['date', 'parcelle_id', 'stress_hydrique']].copy()
        weather_data = self.data_manager.weather_data[['date', 'weather_stress']].copy()
        merged_data = pd.merge(stress_data, weather_data, on='date', how='left')

        # Drop missing values
        merged_data.dropna(subset=['stress_hydrique', 'weather_stress'], inplace=True)
        return merged_data

    def update_plots(self, attr, old, new):
        """
        Met à jour tous les graphiques quand une nouvelle parcelle est sélectionnée.
        """
        selected_parcelle = new
        if 'parcelle_id' not in self.data_manager.monitoring_data.columns:
            print("Warning: Parcel data is missing!")
            return

        # Filter data for the selected parcel
        filtered_monitoring_data = self.data_manager.monitoring_data[
            self.data_manager.monitoring_data['parcelle_id'] == selected_parcelle
        ]
        self.source.data = ColumnDataSource.from_df(filtered_monitoring_data)

    def create_layout(self):
        """
        Organizes all the plots and interactive elements into a layout.
        """
        # Dropdown for parcel selection
        parcelle_options = self.get_parcelle_options()
        select_widget = Select(title="Parcelle:", value=parcelle_options[0], options=parcelle_options)
        select_widget.on_change('value', self.update_plots)

        # Create the plots
        yield_plot = self.create_yield_history_plot()
        ndvi_plot = self.create_ndvi_temporal_plot()
        stress_plot = self.create_stress_matrix()
        prediction_plot = self.create_yield_prediction_plot()

        # Combine dropdown and plots
        layout = column(select_widget, yield_plot, ndvi_plot, stress_plot, prediction_plot)
        return layout



from bokeh.io import curdoc

# Initialize the data manager and load data
data_manager = AgriculturalDataManager()
data_manager.load_data()

# Create and configure the dashboard
dashboard = AgriculturalDashboard(data_manager)
layout = dashboard.create_layout()

# Add the layout to the Bokeh document
curdoc().add_root(layout)
