import folium
from folium import plugins
from branca.colormap import LinearColormap
import pandas as pd
from data_manager import AgriculturalDataManager

class AgriculturalMap:
    def __init__(self, data_manager):
        """
        Initialise la carte avec le gestionnaire de données
        """
        self.data_manager = data_manager
        self.map = None
        self.yield_colormap = LinearColormap(
            colors=['red', 'yellow', 'green'], vmin=0, vmax=12  # Rendement maximum en tonnes/ha
        )

    def create_base_map(self, location=[46.603354, 1.888334], zoom_start=6):
        """
        Crée la carte de base avec les couches appropriées.
        """
        self.map = folium.Map(location=location, zoom_start=zoom_start, tiles='cartodbpositron')

    def add_yield_history_layer(self):
        """
        Ajoute une couche visualisant l’historique des rendements.
        """
        print("Fusion des données...")
        self.data_manager.yield_history = self.data_manager.yield_history.merge(
            self.data_manager.monitoring_data[['parcelle_id', 'latitude', 'longitude']],
            on='parcelle_id',
            how='left'
        )

        # Vérifier les valeurs manquantes
        missing_coords = self.data_manager.yield_history[['latitude', 'longitude']].isnull().sum().sum()
        if missing_coords > 0:
            print(f"Warning: {missing_coords} missing coordinates detected. Skipping these entries.")
            self.data_manager.yield_history.dropna(subset=['latitude', 'longitude'], inplace=True)

        # Utiliser MarkerCluster
        from folium.plugins import MarkerCluster
        marker_cluster = MarkerCluster().add_to(self.map)

        # Limiter les affichages à 100 lignes
        for i, (_, row) in enumerate(self.data_manager.yield_history.iterrows()):
            if i >= 100:  # Limiter pour les tests
                break
            print(f"Traitement de la ligne {i+1}/{len(self.data_manager.yield_history)} : Parcelle {row['parcelle_id']}")

            folium.Marker(
                location=[row['latitude'], row['longitude']],
                popup=f"Parcelle: {row['parcelle_id']}, Rendement: {row['rendement']:.2f}"
            ).add_to(marker_cluster)

    def add_current_ndvi_layer(self):
        """
        Ajoute une couche de la situation NDVI actuelle.
        """
        required_columns = ['latitude', 'longitude', 'ndvi', 'stress_hydrique']
        missing_columns = [col for col in required_columns if col not in self.data_manager.monitoring_data.columns]
        if missing_columns:
            raise ValueError(f"Missing columns in monitoring_data: {missing_columns}")

        for _, row in self.data_manager.monitoring_data.iterrows():
            popup_content = self._create_ndvi_popup(row)

            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=6,
                color='blue',
                fill=True,
                fill_color='blue',
                fill_opacity=0.6,
                popup=popup_content
            ).add_to(self.map)

    def add_risk_heatmap(self):
        """
        Ajoute une carte de chaleur des zones à risque.
        """
        try:
            risk_data = self.data_manager.calculate_risk_metrics(self.data_manager.prepare_features())
            heat_data = [
                [row['latitude'], row['longitude'], row['risque_global']]
                for _, row in risk_data.iterrows()
            ]

            plugins.HeatMap(
                data=[[x[0], x[1], x[2]] for x in heat_data],
                radius=15,
                blur=10,
                max_zoom=10
            ).add_to(self.map)
        except Exception as e:
            print(f"Error calculating risk metrics: {e}")

    def _calculate_yield_trend(self, history):
        """
        Calcule la tendance des rendements pour une parcelle.
        """
        if 'rendement' in history.columns:
            trend = history['rendement'].mean()
        else:
            trend = 0  # Default value if data is missing
        return trend

    def _create_yield_popup(self, history, mean_yield, trend):
        """
        Crée le contenu HTML du popup pour l’historique des rendements.
        """
        return folium.Popup(f"""
        <b>Parcelle:</b> {history['parcelle_id']}<br>
        <b>Rendement Moyen:</b> {mean_yield:.2f} t/ha<br>
        <b>Tendance:</b> {trend:.2f} t/ha/an<br>
        """, max_width=300)

    def _format_recent_crops(self, history):
        """
        Formate la liste des cultures récentes pour le popup.
        """
        crops = history['cultures_recentes'].split(',')
        return '<br>'.join(crops)

    def _create_ndvi_popup(self, row):
        """
        Crée le contenu HTML du popup pour les données NDVI actuelles.
        """
        return folium.Popup(f"""
        <b>Parcelle:</b> {row['parcelle_id']}<br>
        <b>NDVI:</b> {row['ndvi']:.2f}<br>
        <b>Stress Hydrique:</b> {row['stress_hydrique']:.2f}<br>
        """, max_width=300)

    def save_map(self, output_file='agricultural_map.html'):
        """
        Enregistre la carte générée dans un fichier HTML.
        """
        if self.map is not None:
            self.map.save(output_file)
            print(f"Map saved to {output_file}")
        else:
            print("Map has not been created yet. Call create_base_map first.")

# Exemple d'utilisation
if __name__ == "__main__":
    from data_manager import AgriculturalDataManager

    try:
        # Initialisation du gestionnaire de données
        print("Chargement des données...")
        data_manager = AgriculturalDataManager()
        data_manager.load_data()

        # Création de la carte
        print("Création de la carte...")
        agri_map = AgriculturalMap(data_manager)
        agri_map.create_base_map()

        # Ajout des couches
        print("Ajout des couches...")
        agri_map.add_yield_history_layer()
        agri_map.add_current_ndvi_layer()
        agri_map.add_risk_heatmap()
    

        # Enregistrement de la carte
        print("Enregistrement de la carte...")
        agri_map.save_map("agricultural_map.html")
        print("Carte générée avec succès et enregistrée dans 'agricultural_map.html'.")

    except Exception as e:
        print(f"Une erreur s'est produite : {e}")
