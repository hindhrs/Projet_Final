import subprocess
import matplotlib.pyplot as plt
import seaborn as sns
import os

class AgriculturalReportGenerator:
    def __init__(self, analyzer, data_manager):
        """
        Initialize the report generator with the analyzer and data manager.
        """
        self.analyzer = analyzer
        self.data_manager = data_manager
        if not os.path.exists("figures"):
            os.makedirs("figures")  # Ensure the figures directory exists

    def generate_parcelle_report(self, parcelle_id):
        """
        Generate a full report for a given parcelle.
        """
        print(f"Generating report for parcelle {parcelle_id}...")

        # Collect data for the parcelle
        parcelle_data = self.data_manager.prepare_features()
        parcelle_data = parcelle_data[parcelle_data['parcelle_id'] == parcelle_id]

        if parcelle_data.empty:
            print(f"No data available for parcelle {parcelle_id}")
            return

        print("Columns in parcelle_data:", parcelle_data.columns)
        print("Sample data for parcelle:\n", parcelle_data.head())

        if 'rendement_final' not in parcelle_data.columns:
            print("Error: Column 'rendement_final' is missing.")
            return

        yield_analysis = self.analyzer.analyze_yield_factors(parcelle_id)
        correlations = self.analyzer._calculate_yield_correlations(
            parcelle_data['rendement_final'],
            self.data_manager.weather_data,
            self.data_manager.soil_data
        )
        stability_index = self.analyzer._calculate_stability_index(parcelle_data['rendement_final'])

        # Generate markdown content for the report
        print("Creating markdown report...")
        markdown_content = self._create_markdown_report(parcelle_id, yield_analysis, stability_index)

        # Generate figures for the report
        print("Generating figures...")
        self._generate_report_figures(parcelle_id, correlations)

        # Convert markdown to PDF
        print("Converting to PDF...")
        self._convert_to_pdf(markdown_content)

    def _create_markdown_report(self, parcelle_id, analysis, stability_index):
        """
        Create the markdown content for the report.
        """
        markdown = f"""
# Agricultural Report for Parcelle {parcelle_id}

## Historical Analysis
{self._format_historical_analysis(analysis)}

## Stability Analysis
Calculated Stability Index: {stability_index:.2f}

## Recommendations
{self._generate_recommendations(analysis, stability_index)}
        """
        return markdown

    def _generate_report_figures(self, parcelle_id, correlation_data):
        """
        Generate visualizations for the report.
        """
        self._plot_yield_evolution(parcelle_id)
        self._plot_correlation_matrix(correlation_data)
        parcelle_yield_series = self.data_manager.yield_history[
            self.data_manager.yield_history['parcelle_id'] == parcelle_id
        ]['rendement_final']
        self._plot_stability_analysis(parcelle_yield_series)

    def _plot_yield_evolution(self, parcelle_id):
        """
        Plot the yield evolution for the given parcelle.
        """
        parcelle_data = self.data_manager.yield_history[
            self.data_manager.yield_history['parcelle_id'] == parcelle_id
        ]
        plt.figure(figsize=(10, 6))
        plt.plot(parcelle_data['date'], parcelle_data['rendement_final'], marker='o', label='Yield')
        plt.title(f"Yield Evolution for Parcelle {parcelle_id}")
        plt.xlabel("Date")
        plt.ylabel("Yield (t/ha)")
        plt.legend()
        plt.grid()
        plt.savefig(f"figures/yield_evolution_{parcelle_id}.png")
        plt.close()

    def _plot_correlation_matrix(self, correlation_data):
        """
        Plot the correlation matrix for agronomic factors.
        """
        plt.figure(figsize=(12, 8))
        sns.heatmap(correlation_data.to_frame(), annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Matrix of Agronomic Factors")
        plt.savefig("figures/correlation_matrix.png")
        plt.close()

    def _plot_stability_analysis(self, yield_series):
        """
        Plot the stability analysis for yields.
        """
        stability_index = self.analyzer._analyze_yield_stability(yield_series)
        plt.figure(figsize=(10, 6))
        plt.bar(range(len(yield_series)), yield_series, color="green", label="Yield")
        plt.axhline(y=stability_index, color="red", linestyle="--", label="Stability Index")
        plt.title("Yield Stability Analysis")
        plt.xlabel("Time")
        plt.ylabel("Yield (t/ha)")
        plt.legend()
        plt.savefig("figures/stability_analysis.png")
        plt.close()

    def _format_historical_analysis(self, analysis):
        """
        Format historical analysis into a detailed explanatory text.
        """
        return "\n".join([f"- {row['Feature']}: Importance {row['Importance']:.2f}" for _, row in analysis.iterrows()])

    def _generate_recommendations(self, analysis, stability_index):
        """
        Generate agronomic recommendations based on the analysis.
        """
        recommendations = []
        if stability_index < 0.5:
            recommendations.append("Improve parcelle resilience by diversifying crops.")
        recommendations.append("Optimize factors with high importance from the analysis.")
        return "\n".join(recommendations)

    def _convert_to_pdf(self, markdown_content):
        """
        Convert the markdown content to PDF using pandoc.
        """
        with open("report.md", "w") as f:
            f.write(markdown_content)

        try:
            subprocess.run(["pandoc", "report.md", "-o", "report.pdf", "--pdf-engine=xelatex"], check=True)
            print("PDF report generated successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error converting markdown to PDF: {e}")
            print("Ensure pandoc and xelatex are installed.")

if __name__ == "__main__":
    from data_manager import AgriculturalDataManager
    from analyzer import AgriculturalAnalyzer

    # Initialize data manager
    data_manager = AgriculturalDataManager()
    print("Loading Data...")
    data_manager.load_data()

    if data_manager.yield_history.empty:
        print("Error: Yield history data is missing or not loaded correctly.")
    else:
        analyzer = AgriculturalAnalyzer(data_manager)
        report_generator = AgriculturalReportGenerator(analyzer, data_manager)

        # Example parcelle ID
        parcelle_id = 'P001'
        print(f"\n--- Running Analysis for Parcelle: {parcelle_id} ---")

        # Generate the report
        report_generator.generate_parcelle_report(parcelle_id)
