import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.seasonal import seasonal_decompose
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

class AgriculturalDataManager:
    def __init__(self):
        """Initialize the agricultural data manager"""
        self.monitoring_data = None
        self.weather_data = None
        self.soil_data = None
        self.yield_history = None
        self.scaler = StandardScaler()

    def load_data(self):
        try:
            self.monitoring_data = pd.read_csv("data/monitoring_cultures.csv", parse_dates=['date'])
            self.weather_data = pd.read_csv("data/meteo_detaillee.csv", parse_dates=['date'])
            self.soil_data = pd.read_csv("data/sols.csv")
            self.yield_history = pd.read_csv("data/historique_rendements.csv", parse_dates=['date'])
                # Extraire l'année depuis la date
            self.yield_history['annee'] = self.yield_history['date'].dt.year

            # Convertir rendement_final en numérique
            self.yield_history['rendement'] = pd.to_numeric(self.yield_history['rendement_final'], errors='coerce')

            # Traiter les valeurs manquantes
            missing = self.yield_history['rendement'].isnull().sum()
            if missing > 0:
                print(f"Warning: {missing} missing values detected in Yield History. Filling missing values.")
                self.yield_history['rendement'].fillna(self.yield_history['rendement'].mean(), inplace=True)  # Moyenne
        except Exception as e:
            print(f"Error loading data: {e}")


    def _setup_temporal_indices(self):
        """
        Configure temporal indices for time series datasets.
        """
        try:
            self.monitoring_data.set_index('date', inplace=True)
            self.weather_data.set_index('date', inplace=True)
        except KeyError as e:
            print(f"Error in setting temporal indices: {e}")

    def _verify_temporal_consistency(self):
        """
        Check temporal consistency between datasets.
        """
        monitoring_start, monitoring_end = self.monitoring_data.index.min(), self.monitoring_data.index.max()
        weather_start, weather_end = self.weather_data.index.min(), self.weather_data.index.max()

        if not (monitoring_start >= weather_start and monitoring_end <= weather_end):
            print("Warning: Temporal periods of the datasets are inconsistent.")

    def prepare_features(self):
        """
        Prepare features by merging monitoring, weather, and soil data, and enriching with yield history.
        """
        try:
            # Merge monitoring and weather data based on date
            data = pd.merge_asof(
                self.monitoring_data.sort_index(),
                self.weather_data.sort_index(),
                left_index=True,
                right_index=True,
                direction='nearest'
            )

            # Merge the result with soil data
            data = data.merge(self.soil_data, how='left', on='parcelle_id')

            # Enrich with yield history
            data = data.merge(
                self.yield_history[['parcelle_id', 'annee', 'rendement_final']],
                how='left',
                on='parcelle_id'
            )

            # Handle missing values
            missing = data.isnull().sum().sum()
            if missing > 0:
                print(f"Warning: {missing} missing values detected after merging.")
                data.fillna(method='ffill', inplace=True)

            print("Merged data columns:", data.columns)
            return data

        except Exception as e:
            print(f"Error preparing features: {e}")
            return pd.DataFrame()


    def _enrich_with_yield_history(self, data):
        """
        Enrich current data with historical yield information.
        """
        try:
            enriched_data = data.copy()
            enriched_data = enriched_data.merge(
                self.yield_history[['parcelle_id', 'annee', 'rendement']],
                how='left',
                on='parcelle_id'
            )

            # Add historical average yield
            enriched_data['rendement_moyen'] = enriched_data.groupby('parcelle_id')['rendement'].transform('mean')

            return enriched_data
        except Exception as e:
            print(f"Error enriching with yield history: {e}")
            return data

    def calculate_risk_metrics(self, data):
        """
        Calculate risk metrics based on current and historical conditions.
        """
        try:
            # Example metric: Hydric risk
            data['risque_hydrique'] = data['stress_hydrique'] / (data['capacite_retention_eau'] + 1e-6)

            # Example metric: Global risk
            data['risque_global'] = (
                0.5 * data['risque_hydrique'] +
                0.3 * (1 - data['ndvi']) +
                0.2 * (1 - data['rendement_moyen'] / (data['rendement_moyen'].max() + 1e-6))
            )

            return data[['parcelle_id', 'risque_hydrique', 'risque_global']]
        except Exception as e:
            print(f"Error calculating risk metrics: {e}")
            return pd.DataFrame()

    def analyze_yield_patterns(self, parcelle_id):
        try:
            history = self.yield_history[self.yield_history['parcelle_id'] == parcelle_id].copy()

            # Traiter les valeurs manquantes
            if history['rendement'].isnull().sum() > 0:
                print(f"Warning: Missing values for parcel {parcelle_id}. Filling with forward fill.")
                history['rendement'].fillna(method='ffill', inplace=True)

            # Vérifier le nombre de points de données
            if len(history) < 3:
                print(f"Analysis not possible: Not enough data for parcel {parcelle_id}.")
                return None

            # Décomposer la série temporelle
            history.set_index('annee', inplace=True)
            decomposition = seasonal_decompose(history['rendement'], model='additive', period=1)

            # Extraire les composants
            trend = decomposition.trend
            seasonal = decomposition.seasonal
            resid = decomposition.resid

            # Calculer la pente de la tendance et la variation moyenne des résidus
            valid_trend = trend.dropna()
            slope = np.polyfit(valid_trend.index, valid_trend.values, 1)[0]
            variation_mean = resid.std() / history['rendement'].mean()

            return {
                'trend': trend,
                'seasonal': seasonal,
                'resid': resid,
                'pente': slope,
                'variation_moyenne': variation_mean
            }
        except Exception as e:
            print(f"Error analyzing yield patterns: {e}")
            return None

# Example usage
data_manager = AgriculturalDataManager()
data_manager.load_data()
data_manager._setup_temporal_indices()
data_manager._verify_temporal_consistency()

# Préparation des données enrichies
enriched_features = data_manager._enrich_with_yield_history(
    data_manager.prepare_features()
)

# Calcul des métriques de risque
risk_metrics = data_manager.calculate_risk_metrics(enriched_features)
print(risk_metrics.head())

# Analyse des patterns temporels
parcelle_id = 'P001'
patterns = data_manager.analyze_yield_patterns(parcelle_id)
if patterns:
    print(f"Trend slope: {patterns['pente']:.2f} tonnes/ha/year")
    print(f"Average residual variation: {patterns['variation_moyenne']*100:.1f}%")
